﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using TimeController.Models;

namespace TimeController.ViewModels
{
    public class AddTaskDialogViewModel : INotifyPropertyChanged
    {
        public TaskModel Task { get; } = new TaskModel();

        public ObservableCollection<string> TimeOptions { get; } = new();

        public AddTaskDialogViewModel(DateTime? defaultTime = null)
        {
            for (int h = 0; h < 24; h++)
            {
                for (int m = 0; m < 60; m += 1)
                {
                    TimeOptions.Add($"{h:D2}:{m:D2}");
                }
            }

            StartTime = defaultTime?.ToString("HH:mm") ?? "00:00";
            EndTime = "00:00";
        }

        public string Name
        {
            get => Task.Name;
            set { Task.Name = value; OnPropertyChanged(); }
        }

        public string? Note
        {
            get => Task.Note;
            set { Task.Note = value; OnPropertyChanged(); }
        }

        public TaskType Type
        {
            get => Task.Type;
            set { Task.Type = value; OnPropertyChanged(); }
        }

        public bool IsAllDay
        {
            get => Task.IsAllDay;
            set
            {
                Task.IsAllDay = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(IsTimeSelectionEnabled));
            }
        }

        public bool IsReminderEnabled
        {
            get => Task.IsReminderEnabled;
            set { Task.IsReminderEnabled = value; OnPropertyChanged(); }
        }

        public string StartTime { get; set; } = "00:00";
        public string EndTime { get; set; } = "00:00";

        public bool IsTimeSelectionEnabled => !IsAllDay;

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? prop = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }
    }
}
