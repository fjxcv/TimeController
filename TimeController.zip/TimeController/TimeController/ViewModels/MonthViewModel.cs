﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using TimeController.Models;
using TimeController.Views;

namespace TimeController.ViewModels
{
    public class MonthViewModel : INotifyPropertyChanged
    {
        private const int MinYear = 2024;
        private const int MaxYear = 2026;

        public ObservableCollection<DateTime?> CalendarDays { get; } = new();
        public ObservableCollection<TaskModel> AllTasks { get; } = new();

        private int _year = DateTime.Today.Year;
        public int Year
        {
            get => _year;
            set { _year = value; OnPropertyChanged(); UpdateCalendar(); }
        }

        private int _month = DateTime.Today.Month;
        public int Month
        {
            get => _month;
            set { _month = value; OnPropertyChanged(); UpdateCalendar(); }
        }

        public string YearText => $"{Year}年";
        public string MonthText => $"{Month}月";

        public ICommand PrevYearCommand { get; }
        public ICommand NextYearCommand { get; }
        public ICommand PrevMonthCommand { get; }
        public ICommand NextMonthCommand { get; }
        public ICommand ReviewCommand { get; }
        public ICommand DateClickCommand { get; }

        public MonthViewModel()
        {
            PrevYearCommand = new RelayCommand(_ => ChangeYear(-1));
            NextYearCommand = new RelayCommand(_ => ChangeYear(1));
            PrevMonthCommand = new RelayCommand(_ => ChangeMonth(-1));
            NextMonthCommand = new RelayCommand(_ => ChangeMonth(1));
            ReviewCommand = new RelayCommand(_ => ShowReview());
            DateClickCommand = new RelayCommand(date => ShowAddTaskDialog((DateTime)date));

            UpdateCalendar();
        }

        private void ChangeYear(int delta)
        {
            int newYear = Year + delta;
            if (newYear < MinYear || newYear > MaxYear) return;
            Year = newYear;
            OnPropertyChanged(nameof(YearText));
        }

        private void ChangeMonth(int delta)
        {
            int newMonth = Month + delta;
            if (newMonth < 1)
            {
                if (Year > MinYear)
                {
                    Year--;
                    newMonth = 12;
                }
                else return;
            }
            else if (newMonth > 12)
            {
                if (Year < MaxYear)
                {
                    Year++;
                    newMonth = 1;
                }
                else return;
            }
            Month = newMonth;
            OnPropertyChanged(nameof(MonthText));
        }

        private void UpdateCalendar()
        {
            CalendarDays.Clear();
            var firstDay = new DateTime(Year, Month, 1);
            int daysInMonth = DateTime.DaysInMonth(Year, Month);
            int startOffset = ((int)firstDay.DayOfWeek + 6) % 7;

            for (int i = 0; i < startOffset; i++)
                CalendarDays.Add(null);

            for (int day = 1; day <= daysInMonth; day++)
                CalendarDays.Add(new DateTime(Year, Month, day));
        }

        private void ShowReview()
        {
            // TODO: 实现跳转复盘
            System.Windows.MessageBox.Show("跳转复盘页面（待实现）");
        }

        private void ShowAddTaskDialog(DateTime date)
        {
            var dialog = new AddTaskDialog(date);
            if (dialog.ShowDialog() == true && dialog.ResultTask != null)
            {
                AllTasks.Add(dialog.ResultTask);
            }
        }


        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? prop = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }
    }
}
