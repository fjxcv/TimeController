using System;
using System.Windows;
using TimeController.ViewModels;

namespace TimeController.Views
{
    public partial class AddTaskDialog : Window
    {
        public AddTaskDialogViewModel ViewModel { get; }

        public AddTaskDialog(DateTime? defaultTime = null)
        {
            InitializeComponent();
            ViewModel = new AddTaskDialogViewModel(defaultTime);
            DataContext = ViewModel;
        }

        public Models.TaskModel? ResultTask { get; private set; }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            var task = ViewModel.Task;

            task.StartTime = TimeSpan.Parse(ViewModel.StartTime);
            task.EndTime = TimeSpan.Parse(ViewModel.EndTime);

            var errors = task.Validate();
            if (errors.Count > 0)
            {
                MessageBox.Show(string.Join("\n", errors), "校验错误", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ResultTask = task;
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            ResultTask = null;
            DialogResult = false;
        }
    }
}
