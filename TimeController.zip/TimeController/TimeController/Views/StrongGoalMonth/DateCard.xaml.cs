using System;
using System.Windows;
using System.Windows.Controls;

namespace TimeController.Views.StrongGoalMonth
{
    public partial class DateCard : UserControl
    {
        public static readonly DependencyProperty DateProperty = DependencyProperty.Register(
            "Date", typeof(DateTime), typeof(DateCard), new PropertyMetadata(DateTime.Now, OnDateChanged));

        public DateTime Date
        {
            get => (DateTime)GetValue(DateProperty);
            set => SetValue(DateProperty, value);
        }

        public event RoutedEventHandler? DateClicked;

        public DateCard()
        {
            InitializeComponent();
            this.MouseLeftButtonUp += (s, e) => DateClicked?.Invoke(this, new RoutedEventArgs());
        }

        private static void OnDateChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is DateCard card)
            {
                card.DateText.Text = ((DateTime)e.NewValue).Day.ToString();
            }
        }
    }
} 